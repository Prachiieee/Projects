import tkinter as tk
import random

# Define the quiz questions
questions = [
    {
        "question": "What is a Python dictionary?",
        "options": ["A) A collection of elements with ordered indexing",
                    "B) A collection of key-value pairs",
                    "C) A collection of elements with unique values",
                    "D) A collection of elements with fixed size"],
        "answer": "B) A collection of key-value pairs"
    },
    {
        "question": "How do you access the value associated with a key in a dictionary?",
        "options": ["A) Using square brackets and the key",
                    "B) Using square brackets and the index",
                    "C) Using parentheses and the key",
                    "D) Using curly braces and the key"],
        "answer": "A) Using square brackets and the key"
    },
    {
        "question": "Which of the following is not a valid key type in a dictionary?",
        "options": ["A) Integer",
                    "B) String",
                    "C) Float",
                    "D) List"],
        "answer": "D) List"
    },
    {
        "question": "How do you add a new key-value pair to an existing dictionary?",
        "options": ["A) Using the `add()` method",
                    "B) Using the `insert()` method",
                    "C) Using the `update()` method",
                    "D) Using square brackets and assignment"],
        "answer": "D) Using square brackets and assignment"
    },
    {
        "question": "What will be the output of the following code snippet?\nmy_dict = {'a': 1, 'b': 2, 'c': 3}\nprint(my_dict.get('d', 0))",
        "options": ["A) 0",
                    "B) None",
                    "C) KeyError: 'd'",
                    "D) 3"],
        "answer": "A) 0"
    },
]

def next_question():
    global current_question_index
    current_question_index += 1
    if current_question_index < len(questions):
        display_question(current_question_index)
        start_timer()
    else:
        display_final_score()

def prev_question():
    global current_question_index
    current_question_index -= 1
    if current_question_index >= 0:
        display_question(current_question_index)
        start_timer()

def check_answer(answer):
    global score
    if answer == questions[current_question_index]["answer"]:
        score += 1
    next_question()

def display_question(question_index):
    question_label.config(text=questions[question_index]["question"])
    for i in range(4):
        option_buttons[i].config(text=questions[question_index]["options"][i])

def display_final_score():
    question_label.config(text=f"Final Score: {score}/{len(questions)}", fg="blue")
    for button in option_buttons:
        button.grid_remove()
    stop_timer()
    next_button.config(state=tk.DISABLED)
    prev_button.config(state=tk.DISABLED)
    thank_you_label.pack()
    timer_label.pack_forget()

def update_timer():
    global time_left
    time_left -= 1
    timer_label.config(text=f"Time left: {time_left} seconds")
    if time_left == 0:
        display_final_score()
    else:
        timer_label.after(1000, update_timer)

def start_timer():
    global time_left
    time_left = 20  # Set the timer duration in seconds
    update_timer()

def stop_timer():
    global time_left
    time_left = 0

# Create the main window
root = tk.Tk()
root.title("Quiz Game")

# Set the font size
font_size = ("Arial", 20)

# Create title label
title_label = tk.Label(root, text="Welcome to the Quiz Game", font=("Arial", 20, "bold"),fg="blue")
title_label.pack(pady=20)

# Create question label
question_label = tk.Label(root, text="", font=font_size)
question_label.pack(pady=10)

# Create option buttons
option_buttons = []
for i in range(4):
    button = tk.Button(root, text="", font=font_size, width=30,
                       command=lambda i=i: check_answer(questions[current_question_index]["options"][i]))
    option_buttons.append(button)
    button.pack(pady=5)

# Create next and back buttons
next_button = tk.Button(root, text="Next", font=font_size, command=next_question)
next_button.pack(side=tk.RIGHT, padx=10)
prev_button = tk.Button(root, text="Back", font=font_size, command=prev_question)
prev_button.pack(side=tk.LEFT, padx=10)

# Create timer label
timer_label = tk.Label(root, text="", font=font_size)
timer_label.pack(pady=10)

# Create thank you label
thank_you_label = tk.Label(root, text="Thank you for playing!", font=("Arial", 25),fg="blue")

# Shuffle the questions
random.shuffle(questions)

# Initialize variables
current_question_index = 0
score = 0
time_left = 0
final_score_displayed = False

# Display the first question
display_question(current_question_index)
start_timer()

# Start the GUI event loop
root.mainloop()
