/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package text2speech;

import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

/**
 *
 * @author Prachi
 */

public class Text2speech {

    public static void main(String[] args) {
        // Setting the FreeTTS voice directory
        System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");

        // Getting available voices
        VoiceManager voiceManager = VoiceManager.getInstance();
        Voice[] voices = voiceManager.getVoices();
        
        if (voices.length == 0) {
            System.out.println("No voices available. Please make sure FreeTTS is properly configured.");
            return;
        }

        // Selecting a voice
        Voice voice = voiceManager.getVoice("kevin16");
        if (voice == null) {
            System.out.println("Requested voice not available.");
            return;
        }

        // Allocating the selected voice
        voice.allocate();

        // Printing voice information
        System.out.println("Voice Name: " + voice.getName());
        System.out.println("Voice Description: " + voice.getDescription());

        // Setting voice parameters
        voice.setRate(200); // Adjust the speaking rate (words per minute)
        voice.setPitch(100); // Adjust the pitch (default is 100)
        voice.setVolume(1.0f); // Adjust the volume (0.0 to 1.0)

        // Speaking the text
        boolean success = voice.speak("Hello, i am Prachis");
        if (!success) {
            System.out.println("Failed to speak the text.");
        }
        voice.deallocate();
    }
}
