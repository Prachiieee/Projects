function register() {
    var username = document.getElementById('username').value;
    document.write(alert('Registration Successfully: '+ username));
    window.location.href = 'login.html';
  }
  function login() {
    var username = document.getElementById('username').value;
    document.write(alert('Login Successfully :  '+ username));
    window.location.href = 'homepage.html';
  }
  