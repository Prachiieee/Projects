function processPayment() {
    const bill = generateBill();
    alert('Payment Successful!\n\n');
    document.write('Payment Successful!\n\n' + bill);
  }
  
  function generateBill() {  
    const name=document.getElementById('name').value;
    const cardNumber = document.getElementById('cardNumber').value;
    const expirationDate = document.getElementById('expirationDate').value;
    const cvv = document.getElementById('cvv').value;
    const Amount = document.getElementById('Amount').value;
    const bill = `
      <br>Bill Details:<br>
      Name:${name}<br>
      Card Number: ${cardNumber}<br>
      Expiration Date: ${expirationDate}<br>
      CVV: ${cvv}<br>
      Amount:${Amount}<br>
      Total Amount: ${Amount}<br>
      Thank you for your payment! `;
    return bill;
  }
  